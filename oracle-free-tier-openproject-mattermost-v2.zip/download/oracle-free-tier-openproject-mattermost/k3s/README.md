# K3s - Kubernetes Alternativo (OPCIONAL)

> **⚠️ ATENÇÃO:** Esta é uma alternativa OPCIONAL ao Docker Compose padrão.
> Recomendamos o Docker Compose para a maioria dos casos de uso na Oracle A1 Flex (4 OCPU / 24 GB RAM).
> Use K3s apenas se você precisa de recursos avançados do Kubernetes.

## 🤔 Quando Usar K3s vs Docker Compose

| Critério | Docker Compose (Padrão) | K3s (Alternativa) |
|---|---|---|
| **Complexidade** | ✅ Baixa | ⚠️ Média-Alta |
| **Memória mínima** | ~200 MB overhead | ~400-600 MB overhead |
| **Recursos disponíveis para apps** | ~23.5 GB | ~22-23 GB |
| **Auto-healing** | Com restart policies | ✅ Nativo (Deployments) |
| **Rolling updates** | Manual | ✅ Nativo |
| **Scaling** | Manual | ✅ Nativo (HPA) |
| **SSL/TLS** | Certbot/Let's Encrypt | ✅ cert-manager + Traefik |
| **DNS challenge** | Manual | ✅ Automático com Cloudflare |
| **Monitoring** | Docker stats | ✅ Prometheus + Grafana |
| **Backup** | Scripts customizados | ✅ CronJob + Velero |
| **Learning curve** | Baixa | Alta |

### Use Docker Compose se:
- É a primeira vez configurando OpenProject + Mattermost
- Quer a configuração mais simples possível
- Não precisa de auto-scaling
- Prefere depender menos da infraestrutura de orquestração

### Use K3s se:
- Já tem experiência com Kubernetes
- Precisa de rolling updates com zero downtime
- Quer usar Helm charts para gestão de dependências
- Precisa de certificados SSL via DNS-01 challenge (Cloudflare)
- Planeja adicionar mais serviços no futuro

---

## 📋 Pré-requisitos

- **VM Oracle A1 Flex** com 4 OCPU / 24 GB RAM (Free Tier)
- **Ubuntu 22.04 LTS** ARM64
- **Acesso SSH** como root ou com sudo
- **Domínio** configurado no Cloudflare (opcional, para SSL automático)
- **Cloudflare API Token** (se usar DNS-01 challenge para certificados)

---

## 🚀 Início Rápido

### 1. Instalar K3s e dependências

```bash
# Conecte-se na VM
ssh ubuntu@IP_DA_VM

# Baixe e execute o script de instalação
chmod +x k3s/install-k3s.sh
./k3s/install-k3s.sh
```

### 2. Configurar variáveis de ambiente

```bash
# Copie o arquivo de exemplo e edite
cp k3s/.env.example k3s/.env
nano k3s/.env

# Variáveis obrigatórias:
# - DOMAIN_NAME (ex: seudominio.com)
# - OPENPROJECT_SUBDOMAIN (ex: projects)
# - MATTERMOST_SUBDOMAIN (ex: chat)
# - POSTGRES_PASSWORD
# - CLOUDFLARE_API_TOKEN (se usar DNS-01)
# - CLOUDFLARE_EMAIL
```

### 3. Aplicar os manifestos

```bash
# Ordem de aplicação:
cd k3s/

# 1. Namespace
kubectl apply -f namespace.yaml

# 2. Cert-manager (se usar Cloudflare DNS challenge)
kubectl apply -f cert-manager.yaml

# 3. Banco de dados
kubectl apply -f postgresql.yaml

# 4. Memcached
kubectl apply -f memcached.yaml

# 5. OpenProject
kubectl apply -f openproject.yaml

# 6. Mattermost
kubectl apply -f mattermost.yaml

# 7. Backup automático
kubectl apply -f backup-cronjob.yaml
```

### 4. Verificar status

```bash
# Verificar todos os pods
kubectl get pods -n incubadora -w

# Verificar services
kubectl get svc -n incubadora

# Verificar ingress/traefik
kubectl get ingressroute -n incubadora

# Verificar certificados
kubectl get certificates -n incubadora
```

---

## 📁 Estrutura dos Manifestos

```
k3s/
├── README.md                 # Este arquivo
├── install-k3s.sh            # Script de instalação do K3s + Helm + cert-manager
├── .env.example              # Variáveis de ambiente para os manifestos
├── namespace.yaml            # Namespace 'incubadora'
├── postgresql.yaml           # PostgreSQL 17 (StatefulSet + PVC + ConfigMap + Secret)
├── memcached.yaml            # Memcached (Deployment + Service)
├── openproject.yaml          # OpenProject 15 (Deployment + ConfigMap + Secret + IngressRoute)
├── mattermost.yaml           # Mattermost (Deployment + ConfigMap + Secret + IngressRoute)
├── traefik-values.yaml       # Valores do Helm chart do Traefik (ACME + Middlewares)
├── cert-manager.yaml         # ClusterIssuer com Cloudflare DNS solver
└── backup-cronjob.yaml       # CronJob de backup diário do PostgreSQL
```

---

## 🔧 Configuração do SSL/TLS

### DNS-01 Challenge com Cloudflare (Recomendado)

O DNS-01 challenge é mais confiável que HTTP-01, especialmente quando usando Cloudflare proxy:

1. **Crie um API Token no Cloudflare** com permissões `Zone:DNS:Edit`
2. **Configure o `cert-manager.yaml`** com o token
3. **O cert-manager** gera certificados wildcard automaticamente

### Let's Encrypt via DNS-01

```bash
# Editar cert-manager.yaml com suas credenciais Cloudflare
kubectl apply -f cert-manager.yaml

# Aguardar a emissão do certificado
kubectl get certificates -n incubadora -w
```

---

## 📊 Alocação de Recursos (Oracle A1 Flex - 24 GB RAM)

| Componente | CPU | RAM | Observação |
|---|---|---|---|
| **K3s + Traefik** | 0.3 | ~600 MB | Sistema + Ingress Controller |
| **PostgreSQL 17** | 1.0 | 4 GB | StatefulSet com PVC |
| **OpenProject 15** | 1.5 | 3 GB | Deployment |
| **Mattermost** | 0.5 | 2 GB | Deployment |
| **Memcached** | 0.2 | 512 MB | Cache |
| **cert-manager** | 0.1 | 128 MB | Certificados SSL |
| **Total apps** | 3.6 | 10.1 GB | |
| **Disponível** | ~0.4 | ~13.3 GB | Margem de segurança |

---

## 🗑️ Desinstalação

```bash
# Remover tudo (CUIDADO - remove dados!)
kubectl delete namespace incubadora --wait=false

# Desinstalar K3s
/usr/local/bin/k3s-uninstall.sh

# Desinstalar Helm
rm -rf /usr/local/bin/helm /root/.helm /root/.cache/helm
```

---

## 🔗 Links Úteis

- [K3s Documentation](https://docs.k3s.io/)
- [Traefik Helm Chart](https://doc.traefik.io/traefik-helm-chart/)
- [cert-manager Documentation](https://cert-manager.io/docs/)
- [OpenProject Docker Image](https://hub.docker.com/r/openproject/community)
- [Mattermost Docker Image](https://hub.docker.com/r/mattermost/mattermost-team-edition)
